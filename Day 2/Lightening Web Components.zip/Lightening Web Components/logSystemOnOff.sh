echo "$(who -b)" >> /home/lucassoares/Desktop/projects/self_track/logs/systemOnOff.txt

