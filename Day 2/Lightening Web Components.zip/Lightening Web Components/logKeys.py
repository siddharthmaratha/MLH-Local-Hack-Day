import os

os.system("logKeyfreq.sh")